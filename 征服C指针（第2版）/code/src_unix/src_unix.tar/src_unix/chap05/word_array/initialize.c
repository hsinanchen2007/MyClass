#include "word_manage_p.h"

Word    word_array[WORD_NUM_MAX];
int     num_of_word;

/************************************************************
 * 初始化单词管理单元
 ************************************************************/
void word_initialize(void)
{
    num_of_word = 0;
}
