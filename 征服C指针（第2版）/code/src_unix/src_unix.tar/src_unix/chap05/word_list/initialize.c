#include "word_manage_p.h"

Word *word_header = NULL;

/************************************************************
 * 初始化单词管理单元
 ************************************************************/
void word_initialize(void)
{
    word_header = NULL;
}
