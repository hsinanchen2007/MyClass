#ifndef READ_LINE_H_INCLUDED
#define READ_LINE_H_INCLUDED

#include <stdio.h>

char *read_line(FILE *fp);
void free_buffer(void);

#endif /* READ_LINE_H_INCLUDED */
